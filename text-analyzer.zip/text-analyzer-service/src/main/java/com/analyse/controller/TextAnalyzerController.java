package com.analyse.controller;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.analyse.constants.TextAnalyzerConstants;
import com.analyse.dto.TextAnalyzerDto;
import com.analyse.exception.TextAnalyzerException;
import com.analyse.service.TextAnalyzerService;

@RestController
@RequestMapping("/api/v1")
public class TextAnalyzerController {

	@Autowired
	TextAnalyzerService textAnalyzerService;

	@PostMapping(value = "/analyse/text")
	public ResponseEntity<String> analyseText(@RequestBody TextAnalyzerDto textAnalyzerDto) {
		String result = null;
		try {
			result = textAnalyzerService.analyseText(textAnalyzerDto.getText());
		} catch (Exception e) {
			throw new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_FOUND);
		}
		return new ResponseEntity<String>(result, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping(value = "/define/shape/{shape}")
	public ResponseEntity<String> wordToDateTime(@PathVariable("shape") String shape) {
		String result = null;
		try {
			result = textAnalyzerService.defineShape(shape);
		} catch (Exception e) {
			throw new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_FOUND);
		}
		if (result == null) {
			throw new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		return new ResponseEntity<String>(result, new HttpHeaders(), HttpStatus.OK);
	}
}