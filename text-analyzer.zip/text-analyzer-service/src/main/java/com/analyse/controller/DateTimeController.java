package com.analyse.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.analyse.constants.TextAnalyzerConstants;
import com.analyse.exception.TextAnalyzerException;
import com.analyse.service.DateTimeConverterService;

@RestController
@RequestMapping("/api/v1")
public class DateTimeController {

	@Autowired
	DateTimeConverterService dateTimeConverterService;

	@GetMapping(value = "/converter/dateTimeToWord/{dateTime}")
	public ResponseEntity<String> dateTimeToWordConverter(@PathVariable("dateTime") String dateTime) {
		String result = null;
		try {
			result = dateTimeConverterService.convertDateTimeToWord(dateTime);
		} catch (Exception e) {
			throw new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		if (result == null) {
			new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		return new ResponseEntity<String>(result, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping(value = "/converter/wordToDateTime/{word}")
	public ResponseEntity<String> wordToDateTime(@PathVariable("word") String word) {
		String result = null;
		try {
			result = dateTimeConverterService.wordToDateTimeConverter(word);
		} catch (Exception e) {
			new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		if (result == null) {
			new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		return new ResponseEntity<String>(result, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping(value = "/diff/days/{firstDate}/{secondDate}")
	public ResponseEntity<Long> daysDiffernce(@PathVariable("firstDate") String firstDate,
			@PathVariable("secondDate") String secondDate) {
		long result = 0;
		try {
			result = dateTimeConverterService.daysDifference(firstDate, secondDate);
		} catch (Exception e) {
			new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		if (result == 0) {
			new TextAnalyzerException(TextAnalyzerConstants.DATA_NOT_VALID);
		}
		return new ResponseEntity<Long>(result, new HttpHeaders(), HttpStatus.OK);
	}
}