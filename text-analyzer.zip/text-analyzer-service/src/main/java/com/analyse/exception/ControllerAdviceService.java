package com.analyse.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.http.ResponseEntity;
import org.springframework.http.HttpStatus;

@ControllerAdvice
public class ControllerAdviceService {
	
	@ExceptionHandler({RuntimeException.class})
	public ResponseEntity<String> handleException(RuntimeException e){
		return error(HttpStatus.INTERNAL_SERVER_ERROR, e);
	}
	
	@ExceptionHandler({B2CException.class})
	public ResponseEntity<String> handleB2cException(B2CException e){
		return error(HttpStatus.NOT_FOUND, e);
	}
	
	public ResponseEntity<String> error(HttpStatus s,Exception e){
		return ResponseEntity.status(s).body(e.getMessage());
	}

}
