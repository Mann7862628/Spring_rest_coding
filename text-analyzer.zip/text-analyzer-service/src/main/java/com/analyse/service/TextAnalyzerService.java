package com.analyse.service;


public interface TextAnalyzerService {
	public String defineShape(String inputShape) throws Exception;
	public String analyseText(String inputText) throws Exception;
}