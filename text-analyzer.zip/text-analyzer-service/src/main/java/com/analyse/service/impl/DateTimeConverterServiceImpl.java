package com.analyse.service.impl;

import java.time.LocalDateTime;
import org.springframework.stereotype.Service;

import com.analyse.service.DateTimeConverterService;
import com.analyse.utils.TextAnalyzerUtils;

@Service
public class DateTimeConverterServiceImpl implements DateTimeConverterService {

	@Override
	public String convertDateTimeToWord(String inputDateTime) throws Exception {
		LocalDateTime dateTime = TextAnalyzerUtils.parseDateTime(inputDateTime);
		String outputText = TextAnalyzerUtils.formatDateTime(dateTime);
		System.out.println("Input Date Time: " + inputDateTime);
		System.out.println("Output: " + outputText);
		return outputText;
	}

	@Override
	public String wordToDateTimeConverter(String word) throws Exception{
		String output = TextAnalyzerUtils.convertTextToDateTime(word);
		if (output != null) {
			System.out.println("Output: " + output);
		}
		return output;
	}
	
	
	@Override
	public long daysDifference(String firstDate,String secondDate) throws Exception{
		long output = TextAnalyzerUtils.daysDiff(firstDate, secondDate);
		return output;
	}	
}