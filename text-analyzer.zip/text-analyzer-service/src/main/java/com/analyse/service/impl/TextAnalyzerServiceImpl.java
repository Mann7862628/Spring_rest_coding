package com.analyse.service.impl;

import org.springframework.stereotype.Service;

import com.analyse.service.TextAnalyzerService;
import com.analyse.utils.ShapeDefinationUtil;
import com.analyse.utils.TextAnalyzer;
import com.analyse.utils.TextAnalyzerUtils;

@Service
public class TextAnalyzerServiceImpl implements TextAnalyzerService {

	@Override
	public String defineShape(String inputShape) throws Exception{
		String definition = ShapeDefinationUtil.getShapeDefinition(inputShape);
		System.out.println("Output: " + definition);
		return definition;
	}

	@Override
	public String analyseText(String inputText) throws Exception{
		String output = TextAnalyzer.analyzeText(inputText);
		if (output != null) {
			System.out.println("Output: " + output);
		}
		return output;
	}
}