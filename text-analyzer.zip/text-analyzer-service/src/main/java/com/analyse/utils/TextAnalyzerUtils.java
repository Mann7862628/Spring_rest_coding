package com.analyse.utils;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import com.analyse.exception.TextAnalyzerException;

public class TextAnalyzerUtils {

	public static LocalDateTime parseDateTime(String dateTime) throws Exception {
		LocalDateTime localDateTime=null;
		try {
			DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm");
			localDateTime=LocalDateTime.parse(dateTime, formatter);
		} catch (Throwable e) {
			throw new Exception("Please enter the valid  date");
		}
		return localDateTime;
	}

	public static String formatDateTime(LocalDateTime dateTime) {
		String formattedYear = formatYear(dateTime.getYear());
		String hours = formatHours(dateTime.getHour());
		String minutes = formatHours(dateTime.getMinute());

		DateTimeFormatter outputFormatter = DateTimeFormatter.ofPattern(
				"d'th of' MMMM '" + formattedYear + "' '" + hours + "' 'hours past' '" + minutes + "' 'minutes'");
		return dateTime.format(outputFormatter);
	}

	public static String formatHours(int hour) {
		Map<Integer, String> map = new HashMap<Integer, String>();
		map.put(1, "one");
		map.put(2, "two");
		map.put(3, "three");
		map.put(4, "four");
		map.put(5, "five");
		map.put(6, "six");
		map.put(7, "seven");
		map.put(8, "eight");
		map.put(9, "nine");
		map.put(10, "teen");
		map.put(11, "eleven");
		map.put(12, "twelve");
		map.put(13, "thirteen");
		map.put(14, "fourteen");
		map.put(15, "fifteen");
		map.put(16, "sixteen");
		map.put(17, "seventeen");
		map.put(18, "eighteen");
		map.put(19, "nineteen");
		map.put(20, "twenty");
		map.put(30, "thirty");
		map.put(40, "forty");
		map.put(50, "fifty");
		map.put(60, "sixty");
		map.put(70, "seventy");
		map.put(80, "eighty");
		map.put(90, "ninty");

		return map.get(hour);
	}

	public static String formatYear(int year) {
		String[] units = { "", "one", "two", "three", "four", "five", "six", "seven", "eight", "nine" };
		String[] teens = { "eleven", "twelve", "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", "eighteen",
				"nineteen" };
		String[] tens = { "", "ten", "twenty", "thirty", "forty", "fifty", "sixty", "seventy", "eighty", "ninety" };

		if (year >= 1000 && year <= 9999) {
			int thousand = year / 1000;
			int hundred = (year % 1000) / 100;
			int ten = (year % 100) / 10;
			int unit = year % 10;

			StringBuilder sb = new StringBuilder();
			if (thousand > 0) {
				sb.append(units[thousand]).append(" thousand ");
			}
			if (hundred > 0) {
				sb.append(units[hundred]).append(" hundred ");
			}
			if (ten > 1) {
				sb.append(tens[ten]);
				if (unit > 0) {
					sb.append(" ").append(units[unit]);
				}
			} else if (ten == 1) {
				sb.append(teens[unit - 1]);
			} else if (unit > 0) {
				sb.append(units[unit]);
			}
			return sb.toString().trim();
		} else {
			return String.valueOf(year);
		}
	}

	private static Map<String, Integer> map = new HashMap<String, Integer>();
	static {
		map.put("one", 1);
		map.put("two", 2);
		map.put("three", 3);
		map.put("four", 4);
		map.put("five", 5);
		map.put("six", 6);
		map.put("seven", 7);
		map.put("eight", 8);
		map.put("nine", 9);
		map.put("ten", 10);
		map.put("eleven", 11);
		map.put("twelve", 12);
		map.put("thirteen", 13);
		map.put("fourteen", 14);
		map.put("fifteen", 15);
		map.put("sixteen", 16);
		map.put("seventeen", 17);
		map.put("eighteen", 18);
		map.put("ninteen", 19);
		map.put("twenty", 20);
		map.put("thirty", 30);
		map.put("forty", 40);
		map.put("fifty", 50);
		map.put("sixty", 60);
		map.put("seventy", 70);
		map.put("eighty", 80);
		map.put("ninety", 90);
	}

	public static String convertTextToDateTime(String text) {
		try {
			// Splitting the input text to extract date and time components
			String[] parts = text.split(" ");

			// Extracting day, month, and year
			int day = extractDay(parts[0]);
			String month = parts[2];
			int year = extractYear(parts);

			// Extracting hour and minute
			int hour = map.get(parts[7]);
			int minute = map.get(parts[10]);

			// Creating a Calendar instance and setting the extracted components
			Calendar calendar = Calendar.getInstance();
			calendar.set(Calendar.DAY_OF_MONTH, day);
			calendar.set(Calendar.MONTH, getMonthIndex(month));
			calendar.set(Calendar.YEAR, year);
			calendar.set(Calendar.HOUR_OF_DAY, hour);
			calendar.set(Calendar.MINUTE, minute);

			// Formatting the date and time as per the desired output
			SimpleDateFormat outputFormat = new SimpleDateFormat("dd-MM-yyyy HH:mm");
			return outputFormat.format(calendar.getTime());
		} catch (Exception e) {
			System.out.println("Error: " + e.getMessage());
			return null;
		}
	}

	private static int extractDay(String dayString) {
		// Extracting the numeric part of the day
		return Integer.parseInt(dayString.replaceAll("[^0-9]", ""));
	}

	private static int extractYear(String[] parts) {
		int p1 = 0;
		int p2 = 0;
		for (int i = 0; i < parts.length; i++) {
			if (parts[i].equalsIgnoreCase("thousand")) {
				p1 = 2000;
			} else {
				if (i == 5 || i == 6) {
					p2 = p2 + map.get(parts[i]);
				}
			}

		}
		if (p1 + p2 > 0) {
			return p1 + p2;
		}
		// If no valid year found, throw an exception
		throw new NumberFormatException("Invalid year format");
	}

	private static int getMonthIndex(String month) {
		String[] months = new SimpleDateFormat("MMMM", Locale.ENGLISH).getDateFormatSymbols().getMonths();
		for (int i = 0; i < months.length; i++) {
			if (months[i].equalsIgnoreCase(month)) {
				return i;
			}
		}
		return 0; // Default to January if month is not found
	}

	public static long daysDiff(String date1, String date2) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
		LocalDate d1 = LocalDate.parse(date1, formatter);
		LocalDate d2 = LocalDate.parse(date2, formatter);
		return ChronoUnit.DAYS.between(d1, d2);
	}
}