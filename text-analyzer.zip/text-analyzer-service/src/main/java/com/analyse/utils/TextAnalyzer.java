package com.analyse.utils;

public class TextAnalyzer {

	public static String analyzeText(String text) {
		int wordCount = countWords(text);
		int vowelCount = countVowels(text);
		int sentenceCount = countSentences(text);
		String result = "Words: " + wordCount + ", Vowels: " + vowelCount + ", Sentences: " + sentenceCount;
		System.out.println(result);
		return result;
	}

	private static int countWords(String text) {
		String[] words = text.split("\\s+");
		return words.length;
	}

	private static int countVowels(String text) {
		int vowelCount = 0;
		String vowels = "aeiouAEIOU";

		for (char c : text.toCharArray()) {
			if (vowels.indexOf(c) != -1) {
				vowelCount++;
			}
		}

		return vowelCount;
	}

	private static int countSentences(String text) {
		String[] sentences = text.split("[.!?]");
		return sentences.length;
	}
}
