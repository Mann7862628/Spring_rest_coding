package com.analyse.constants;

public class TextAnalyzerConstants {

	public static final String DATA_NOT_FOUND = "Data not found";
	public static final String DATA_NOT_VALID = "Please enter the valid data";
}
